<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>A9</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="style.css">
    </head>
    <body class="bg-dark">
        <div class="mt-5 rounded container p-4 text-center bg-light">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php">Početna</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Uputstvo.php">Uputstvo</a>
                        </li>
                    </ul>
                </div>
            </nav>
            <form action="index.php">
                <div class="row">
                    <div class="col-5">
                        <label for="cir">Ćirilica</label>
                        <textarea id="cir" class="form-control" name="cir" rows="5"></textarea>
                    </div>
                    <div class="col-2">
                        <label for="akcija">Akcija</label>
                        <div id="akcija" class="p-4">
                            <input type="submit" class="btn btn-info btn-block" value="U latinicu" name="ulat" />
                            <input type="submit" class="btn btn-info btn-block" value="U ćirilicu" name="ucir" />
                        </div>
                    </div>
                    <div class="col-5">
                        <label for="lat">Latinica</label>
                        <textarea id="lat" class="form-control" name="lat" rows="5"></textarea>
                    </div>
                    
                    <div class="col-12 py-4">
                        <label for="kt">Konvertovan tekst</label>
                        <textarea id="kt" class='form-control' readonly><?php require_once 'Convert.php'; ?></textarea>
                    </div>
                </div>
            </form>
            
        </div>
    </body>
</html>
